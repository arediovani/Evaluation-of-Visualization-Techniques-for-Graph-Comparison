const { execSync } = require('child_process');

const conditions = ['pos1', 'pos2', 'pos3'];
const questions = ['q1', 'q2', 'q3'];
const repetitions = ['rep1', 'rep2', 'rep3'];
const initialNodeCounts = [50, 65, 80];

function runScript(condition, question, repetition, initialNodeCount) {
  process.env.INITIAL_NODE_COUNT = initialNodeCount.toString(); // Set environment variable
  const script = `node graph-generation.js ${initialNodeCount}`;
  const graph1FileName = `${condition}_${question}_${repetition}_graph1`;
  const graph2FileName = `${condition}_${question}_${repetition}_graph2`;

  try {
    execSync(`${script} ${graph1FileName} ${graph2FileName}`);
    console.log(`Successfully generated graphs for ${condition}_${question}_${repetition}`);
  } catch (error) {
    console.error(`Error generating graphs for ${script} ${graph1FileName} ${graph2FileName}`);
  }
}

async function generateGraphs() {
  for (const condition of conditions) {
    for (const question of questions) {
      for (const repetition of repetitions) {
            await runScript(condition, question, repetition, initialNodeCounts[repetitions.indexOf(repetition)]);
      }
    }
  }
}

generateGraphs();
