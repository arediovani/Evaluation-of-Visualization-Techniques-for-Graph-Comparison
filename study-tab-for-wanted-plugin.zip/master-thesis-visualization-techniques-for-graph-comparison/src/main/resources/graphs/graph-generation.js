const fs = require('fs');
const path = require('path');

// Adjust here to vary graphs
const initialNumberOfNodes = parseInt(process.env.INITIAL_NODE_COUNT) || 100;
const desiredDensity = 1.25;

const nodeDeletionProportion = 0.05;
const edgeDeletionProportion = 0.05;
const nodeAlterationProportion = 0.05;
const edgeAlterationProportion = 0.05;

// Below here, no adjustments necessary

const edgeProbability = desiredDensity * initialNumberOfNodes / ( initialNumberOfNodes * ( initialNumberOfNodes - 1 ));

const nodes = [];
const edges = [];

// Generate basic set of nodes
Array.from( Array(initialNumberOfNodes).keys() ).map( d => (d+1) ).forEach( n => {
    nodes.push({
        id: n,
        val: Math.max( 1, Math.round( 100 * Math.random() ))
    });
});

// Generate basic set of edges
let edgeCounter = 1;
for( let i = 0; i < nodes.length; i++ ) {
    for( let j = 0; j < nodes.length; j++ ) {
        if ( i === j ) { continue; }
        if ( Math.random() <= edgeProbability ) {
            edges.push({
                id: edgeCounter++,
                val: Math.max( 1, Math.round( 100 * Math.random() )),
                source: nodes[i].id,
                target: nodes[j].id
            });
        }
    }
}

// Compute actual numbers depending on graph size
const numberOfNodesToDelete = Math.round( initialNumberOfNodes * nodeDeletionProportion );
const numberOfEdgesToDelete = Math.round( edges.length * edgeDeletionProportion );
const numberOfNodesToAlter = Math.round( initialNumberOfNodes * nodeAlterationProportion );
const numberOfEdgesToAlter = Math.round( edges.length * edgeAlterationProportion );


function shuffle(array) {
    
    let currentIndex = array.length;
    let randomIndex;

    while (currentIndex !== 0) {

        randomIndex = Math.floor( Math.random() * currentIndex );
        currentIndex--;

        [ array[currentIndex], array[randomIndex] ] = [ array[randomIndex], array[currentIndex] ];

    }

    return array;

};

// Delete the given 'number' of nodes provided from the given set called 'nodes'. Edges that were incident to removed nodes will also be removed.
const deleteNodes = ( nodes, edges, number ) => {
    let counter = number;
    let position;
    while ( counter > 0 ) {
        position = Math.round( Math.random() * nodes.length );
        // console.log(`Removed node ${nodes[position].id}`);
        nodes.splice(position, 1);
        counter -= 1;
    }

    return edges.filter( edge => {
        const containsSource = (nodes.filter( n => ( n.id === edge.source )).length > 0);
        const containsTarget = (nodes.filter( n => ( n.id === edge.target )).length > 0);
        if ( ! (containsSource && containsTarget) ) {
            console.log(`Had to remove edge ${edge.id}`);
        }
        return containsSource && containsTarget;
    });
};

// Delete the given 'number' of edges provided from the given set called 'edges'.
const deleteEdges = ( edges, number ) => {
    let counter = number;
    let position;
    while ( counter > 0 ) {
        position = Math.floor( Math.random() * edges.length );
        console.log(`Removed edge ${edges[position].id}`);
        edges.splice(position, 1);
        counter -= 1;
    }
};

// Alter node values according to specified proportion
const alterNodes = ( nodes, number ) => {
    const positions = shuffle( Array.from( Array( nodes.length ).keys())).slice(0, number);
    console.log(`alternodepositions: ${positions}`);

    positions.forEach( pos => {
        const oldVal = nodes[pos].val;
        nodes[pos].val = Math.max( 1, Math.round( nodes[pos].val * ( Math.random() + 0.5 )));
        console.log(`Altered value of ${nodes[pos].id} from ${oldVal} to ${nodes[pos].val}`);
    });
};

// Alter edge values according to specified proportion
const alterEdges = ( edges, number ) => {
    const positions = shuffle( Array.from( Array( edges.length ).keys())).slice(0, number);
    console.log(`alteredgepositions: ${positions}`);

    positions.forEach( pos => {
        edges[pos].val = Math.max( 1, Math.round( edges[pos].val * ( Math.random() + 0.5 )));
    });
};

// write the given node and edge sets as gml file
const writeGML = ( nodes, edges, fileName ) => {
    console.log(initialNumberOfNodes)
    const strs = [];
    console.log(initialNumberOfNodes)
    strs.push('graph [');

    nodes.forEach( node => {
        strs.push(`    node [`);
        strs.push(`        id ${node.id}`);
        strs.push(`        identifier ${node.id}`);
        strs.push(`        label "node-${node.id}"`);
        strs.push(`        value ${node.val}`);
        strs.push(`        graphics [`);
        strs.push(`            x ${ ( Math.random() * 2000 + 50 ).toFixed(2) }`);
        strs.push(`            y ${ ( Math.random() * 2000 + 50 ).toFixed(2) }`);
        strs.push(`        ]`);
        strs.push(`    ]`);
    });

    edges.forEach( edge => {
        strs.push(`    edge [`);
        strs.push(`        id ${edge.id}`);
        strs.push(`        identifier ${edge.id}`);
        strs.push(`        label "${edge.val}"`);
        strs.push(`        value ${edge.val}`);
        strs.push(`        source ${edge.source}`);
        strs.push(`        target ${edge.target}`);
        strs.push(`    ]`);
    });

    strs.push(']');

    const str = strs.join('\n');

    try {
        fs.writeFileSync(path.join(__dirname, fileName+'.gml'), str);
    } catch (err) {
        console.error(err)
    }

};

// Create empty sets for the two graphs
const nodesGraph1 = [];
const nodesGraph2 = [];
let edgesGraph1 = [];
let edgesGraph2 = [];

// initially, copy nodes from basic set
nodes.forEach( node => {
    nodesGraph1.push({
        id: node.id,
        val: node.val
    });
    nodesGraph2.push({
        id: node.id,
        val: node.val
    });
});

// initially, copy edges from basic set
edges.forEach( edge => {
    edgesGraph1.push({
        id: edge.id,
        val: edge.val,
        source: edge.source,
        target: edge.target
    });
    edgesGraph2.push({
        id: edge.id,
        val: edge.val,
        source: edge.source,
        target: edge.target
    });
});

// Perform deletions and alterations
edgesGraph1 = deleteNodes( nodesGraph1, edgesGraph1, numberOfNodesToDelete );
edgesGraph2 = deleteNodes( nodesGraph2, edgesGraph2, numberOfNodesToDelete );
deleteEdges( edgesGraph1, numberOfEdgesToDelete );
deleteEdges( edgesGraph2, numberOfEdgesToDelete );
alterNodes( nodesGraph1, numberOfNodesToAlter );
alterNodes( nodesGraph2, numberOfNodesToAlter );
alterEdges( edgesGraph1, numberOfEdgesToAlter );
alterEdges( edgesGraph2, numberOfEdgesToAlter );

// Finally, write the two graphs
writeGML( nodesGraph1, edgesGraph1, process.argv[3] );
writeGML( nodesGraph2, edgesGraph2,  process.argv[4]);
