/*************************************************************************************
 * The Exemplary Add-on is (c) 2008-2011 Plant Bioinformatics Group, IPK Gatersleben,
 * http://bioinformatics.ipk-gatersleben.de
 * The source code for this project, which is developed by our group, is
 * available under the GPL license v2.0 available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html. By using this
 * Add-on and VANTED you need to accept the terms and conditions of this
 * license, the below stated disclaimer of warranties and the licenses of
 * the used libraries. For further details see license.txt in the root
 * folder of this project.
 ************************************************************************************/
package org.vanted.addons.graphcompareaddon;

import org.vanted.addons.graphcompareaddon.comparisionalgorithm.Difference;
import org.vanted.addons.graphcompareaddon.comparisionalgorithm.JuxtaPosition;
import org.vanted.addons.graphcompareaddon.comparisionalgorithm.SuperPosition;

import de.ipk_gatersleben.ag_nw.graffiti.GraphHelper;
import de.ipk_gatersleben.ag_nw.graffiti.plugins.gui.editing_tools.CloseAllWindows;
import de.ipk_gatersleben.ag_nw.graffiti.plugins.gui.zoomfit.ZoomFitChangeComponent;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JToggleButton;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import org.BackgroundTaskStatusProviderSupportingExternalCall;
import org.ErrorMsg;
import org.graffiti.editor.MainFrame;
import org.graffiti.editor.MessageType;
import org.graffiti.event.GraphEvent;
import org.graffiti.event.GraphListener;
import org.graffiti.event.ListenerManager;
import org.graffiti.event.ListenerNotFoundException;
import org.graffiti.event.TransactionEvent;
import org.graffiti.graph.AdjListGraph;
import org.graffiti.graph.Graph;
import org.graffiti.graph.GraphElement;
import org.graffiti.plugin.inspector.InspectorTab;
import org.graffiti.plugin.view.View;
import org.graffiti.plugin.view.ViewListener;
import org.graffiti.plugins.inspectors.defaults.DefaultEditPanel;
import org.graffiti.plugins.views.defaults.GraffitiView;
import org.graffiti.selection.SelectionEvent;
import org.graffiti.selection.SelectionListener;
import org.graffiti.session.EditorSession;
import org.graffiti.session.Session;
import org.graffiti.session.SessionListener;
import org.graffiti.util.DesktopMenuManager;
import org.graffiti.util.MenuAdapter;

/**
 * 
 * AddonTab class represents a GUI panel that contains various components for
 * visualizing and manipulating graphs. It loads two graph files and displays
 * them using MainFrame. The panel contains components for setting node and edge
 * colors, selecting node attributes, stacking and superimposing graphs, and
 * performing difference operations. It also provides a tabbed interface for
 * organizing different types of operations.
 * 
 * @author Aredio Vani
 */
public class AddonTab extends InspectorTab implements ViewListener, SessionListener, GraphListener, SelectionListener {

	private File graph1;	
	private File graph2;
	private JPanel mainPanel;
	private JTabbedPane tabSubPanel;
	private JPanel juxtaPositionPanel;
	private JPanel superPositionPanel;
	private JPanel differencePanel;
	private JLabel statusText;
	private String mainGraph;
	private Color nodeColor = Color.RED;
	private Color edgeColor = Color.BLUE;
	private JComboBox attributeList;
	private String[] nodeAttributes = new String[] { "label", "identifier" };
	private JComboBox super_selectEdgeUnOverlap;
	private String selectedAttribute = "label";
	private String[] edgeUnOverlapMethods = new String[] { "Bend", "Concat","difference" };
	private String selectedUnOverlap = "Bend";
	private CloseAllWindows closeAllWindows;
	private JCheckBox keepOriginalColor;
	private JLabel EdgeColorEx;
	private JLabel NodeColorEx;
	
	private JCheckBox juxta_EnableNaive;
	private JCheckBox juxta_Synchronize;
	private JButton juxta_changePosition;
	private JRadioButton juxta_VerticalPosition;
	private JRadioButton juxta_HorizontalPosition;
	private ButtonGroup juxta_radioGroup;
	private JButton initializeButton;
	private String selectedStack;

	private JRadioButton super_EnableDistance;
	private JRadioButton super_EnableOpacity;
	private ButtonGroup super_group;
	private JSlider super_DistanceSlider;
	private JSlider super_DegreeSlider;
	private JSlider super_OpacitySlider;
	private JButton super_Initiate;

	private static final long serialVersionUID = 1L;

	// it is dangerous to save a graph. if you need it be sure to release the
	// reference on null-sessions or views
	private Graph graph;
	private Graph[] graphs = new Graph[2];

	/**
	 * Please refer to the implementation of InspectorTab to see the inherited
	 * methods and fields.
	 */
	public AddonTab() {

		
		setLayout(new BorderLayout());
//		setAlignmentX(Component.LEFT_ALIGNMENT); // Use Component.LEFT_ALIGNMENT instead of this.LEFT_ALIGNMENT

		mainPanel = new JPanel();
		Border mainPanelBorder = BorderFactory.createTitledBorder("Global Compare Settings");
		BoxLayout mainPanelLayout = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
		mainPanel.setLayout(mainPanelLayout);
		mainPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
		
		EdgeColorEx= new JLabel("\u2588");
		EdgeColorEx.setForeground(Color.BLACK);
		NodeColorEx= new JLabel("\u2588");
		NodeColorEx.setForeground(Color.BLACK);
		
		
		
		JButton selectColorNode = new JButton("Color for duplicate Nodes");
		selectColorNode.setEnabled(true);
		selectColorNode.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Show dialog to select background color
				nodeColor = JColorChooser.showDialog(mainPanel, "Choose Background Color", Color.WHITE);
				NodeColorEx.setForeground(nodeColor);
			}
		});

		// Create a button that initializes the comparing
		JButton selectColorEdge = new JButton("Color for duplicate Edge");
		selectColorEdge.setEnabled(true);
		selectColorEdge.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Show dialog to select color for duplicate edges
				edgeColor = JColorChooser.showDialog(mainPanel, "Choose a color for duplicate edges", Color.WHITE);
				EdgeColorEx.setForeground(edgeColor);
			}
		});
		
		attributeList = new JComboBox(nodeAttributes);
		attributeList.setSelectedIndex(0);
//		attributeList.setMaximumSize(new Dimension(150, 250));
		attributeList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Update selected attribute
				JComboBox cb = (JComboBox) e.getSource();
				selectedAttribute = (String) cb.getSelectedItem();
				
			}
		});

		JButton main_ResetGraph = new JButton("Reset Graph");
		main_ResetGraph.setEnabled(true);
		main_ResetGraph.addActionListener(e -> resetGraph());

		super_selectEdgeUnOverlap = new JComboBox(edgeUnOverlapMethods);
//		super_selectEdgeUnOverlap.setMaximumSize(new Dimension(120, 25));
		super_selectEdgeUnOverlap.setSelectedIndex(0);
		super_selectEdgeUnOverlap.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Update selected attribute
				JComboBox cb = (JComboBox) e.getSource();
				selectedUnOverlap = (String) cb.getSelectedItem();
			}
		});
		
		// Add components to main panel
		statusText = new JLabel();
		mainPanel.add(statusText);
		mainPanel.add(attributeList);
		mainPanel.add(selectColorNode);
		mainPanel.add(NodeColorEx);
		mainPanel.add(selectColorEdge);
		mainPanel.add(EdgeColorEx);
		mainPanel.add(super_selectEdgeUnOverlap);
		mainPanel.add(main_ResetGraph);
		add(mainPanel,"North");

//--------------------------JUXTA POSITION---------------------------------------
		// Create panel for juxta position operations
		juxtaPositionPanel = new JPanel();
		juxtaPositionPanel.setBorder(new EmptyBorder(10, 5, 10, 20));
		juxtaPositionPanel.setLayout(new BoxLayout(juxtaPositionPanel, BoxLayout.Y_AXIS));

		// Create toggle button for synchronization
		juxta_Synchronize = new JCheckBox("Synchronize Views");
		juxta_Synchronize.setEnabled(true);

		juxta_EnableNaive = new JCheckBox("Naive Juxta");
		juxta_EnableNaive.setEnabled(true);

		// Create button to change positions
		juxta_changePosition = new JButton("Switch Views");
		juxta_changePosition.setEnabled(true);
		juxta_changePosition.addActionListener(event -> getName());

		// Create radio buttons for left/right
		juxta_VerticalPosition = new JRadioButton("Vertical");
		juxta_HorizontalPosition = new JRadioButton("Horizontal");
		juxta_HorizontalPosition.setSelected(true);
		juxta_VerticalPosition.addActionListener(e -> selectedStack = juxta_VerticalPosition.getText());
		juxta_HorizontalPosition.addActionListener(e -> selectedStack = juxta_HorizontalPosition.getText());

		juxta_radioGroup = new ButtonGroup();
		juxta_radioGroup.add(juxta_VerticalPosition);
		juxta_radioGroup.add(juxta_HorizontalPosition);

		// Create button to initialize
		initializeButton = new JButton("Initialize");
		initializeButton.setEnabled(true);

		initializeButton.addActionListener(
				e -> juxta_Initialize(juxta_EnableNaive.isSelected(), juxta_Synchronize.isSelected(), selectedStack));


		// Add components to juxta position panel
		juxtaPositionPanel.add(juxta_EnableNaive);
		juxtaPositionPanel.add(juxta_Synchronize);
		juxtaPositionPanel.add(juxta_HorizontalPosition);
		juxtaPositionPanel.add(juxta_VerticalPosition);
		juxtaPositionPanel.add(juxta_changePosition);
		juxtaPositionPanel.add(initializeButton);

//--------------------------SUPER POSITION---------------------------------------
		// Create panel for super position operations
		superPositionPanel = new JPanel();
		superPositionPanel.setLayout(new BoxLayout(superPositionPanel,BoxLayout.Y_AXIS));

		super_EnableDistance = new JRadioButton("Change Distance", true);
		super_EnableOpacity = new JRadioButton("Impose with opacity");

		super_EnableDistance.addActionListener(e -> {
		    boolean isSelected = super_EnableDistance.isSelected();
		    super_DistanceSlider.setEnabled(isSelected);
		    super_DegreeSlider.setEnabled(isSelected);
		    super_OpacitySlider.setEnabled(!isSelected);
		    super_selectEdgeUnOverlap.setEnabled(!isSelected);
		});

		super_EnableOpacity.addActionListener(e -> {
		    boolean isSelected = super_EnableOpacity.isSelected();
		    super_DistanceSlider.setEnabled(!isSelected);
		    super_DegreeSlider.setEnabled(!isSelected);
		    super_OpacitySlider.setEnabled(isSelected);
		    super_selectEdgeUnOverlap.setEnabled(isSelected);
		});



		// ... Create a button group and add the buttons.
		super_group = new ButtonGroup();
		super_group.add(super_EnableDistance);
		super_group.add(super_EnableOpacity);


		super_DistanceSlider = new JSlider(JSlider.HORIZONTAL, 0, 50, 5);
		super_DistanceSlider
				.setToolTipText("Change how far you want to move the duplicated nodes, the value is in pixels");
		super_DistanceSlider.setPaintTicks(true);
		super_DistanceSlider.setPaintLabels(true);
		super_DistanceSlider.setEnabled(true);
		super_DistanceSlider.setMajorTickSpacing(5);

		super_DegreeSlider = new JSlider(JSlider.HORIZONTAL, 0, 360, 90);
		super_DegreeSlider.setToolTipText("Change the deegre of the direction of the duplicated node");
		super_DegreeSlider.setPaintTicks(true);
		super_DegreeSlider.setPaintLabels(true);
		super_DegreeSlider.setEnabled(true);
		super_DegreeSlider.setMajorTickSpacing(90);

		super_OpacitySlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 10);
		super_OpacitySlider.setPaintTicks(true);
		super_OpacitySlider.setPaintLabels(true);
		super_OpacitySlider.setEnabled(false);
		super_OpacitySlider.setMajorTickSpacing(10);


		
		// Create button to initiate super position operation
		super_Initiate = new JButton("Initialize");
		super_Initiate.setEnabled(true);
		super_Initiate.addActionListener(e -> SuperPositionClicked());

		
		
		// Add button to super position panel
		superPositionPanel.add(super_EnableDistance);
		superPositionPanel.add(super_DistanceSlider);
		superPositionPanel.add(super_DegreeSlider);
		superPositionPanel.add(super_EnableOpacity);
		superPositionPanel.add(super_OpacitySlider);
		superPositionPanel.add(super_Initiate);

//--------------------------ENCODING POSITION---------------------------------------
		// Create panel for difference operations
		differencePanel = new JPanel();
		differencePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
		differencePanel.setBackground(Color.lightGray);
		JButton differenceInitiate = new JButton("Explicit Encoding Additive");
		differenceInitiate.setEnabled(true);
		differenceInitiate.addActionListener(e -> DifferenceClicked(false));
		differencePanel.add(differenceInitiate);

		JButton juxtaExplicit = new JButton("Juxta Position + Explicit Encoding");
		juxtaExplicit.setEnabled(true);
		juxtaExplicit.addActionListener(e -> DifferenceClicked(true));
		differencePanel.add(juxtaExplicit);

//--------------------------TABBING---------------------------------------
		tabSubPanel = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
		tabSubPanel.addTab("Juxta", juxtaPositionPanel);
		tabSubPanel.addTab("Super", superPositionPanel);
		tabSubPanel.addTab("Difference / Encoding", differencePanel);
		add(tabSubPanel,"Center");
		this.
		validate();
	}

	@Override
	public String getName() {
		return getTitle();
	}

	/**
	 * Don't forget to set the title, otherwise the tab won't be shown.
	 */
	@Override
	public String getTitle() {
		return "Graph-Comparison";
	}

	/**
	 * Vanted will ask every time all tabs, when a view changes, if this tab wants
	 * to be hidden or not.
	 */
	@Override
	public boolean visibleForView(View v) {
		return true;
	}

	
	public void resetGraph() {
		closeAllWindows = new CloseAllWindows();
		closeAllWindows.execute();
		MainFrame.getInstance().loadGraph(graph1);
		MainFrame.getInstance().loadGraph(graph2);

	}
	/**
	 * For demonstration purposes this tab listens to a view change and just prints
	 * out the view and creates an exemplary {@FolderPanel} .
	 */
	public void viewChanged(View newView) {
		try {
			mainGraph = MainFrame.getInstance().getActiveEditorSession().getFileName();
			statusText.setText("Selected graph for comparing: " + mainGraph);
			;
		} catch (NullPointerException e) {
			mainGraph = "NewGraph";
		}
		Set<EditorSession> editorSessions = MainFrame.getInstance().getEditorSessions();

		for (EditorSession currentGraph : editorSessions) {
			if (currentGraph.getFileName().equals(mainGraph)) {
				graphs[0] = currentGraph.getGraph();
			} else {
				graphs[1] = currentGraph.getGraph();
			}
		}
		if (newView == null)
			;// free resources
	}

	private void juxta_Initialize(boolean naive, boolean synchronize, String stackPosition) {
		if (!naive) {
			JuxtaPosition.calculateJuxtaposition(graphs, selectedAttribute);
		}
		Stack(stackPosition);
	}

	private void SuperPositionClicked() {

		Graph newGraph = new AdjListGraph();

//		if (super_EnableDistance.isSelected()) {
//			newGraph = SuperPosition.calculateSuperposition(graphs, selectedAttribute, nodeColor,
//					super_DistanceSlider.getValue(), super_DegreeSlider.getValue(), 100);
//
//		} else if (super_EnableOpacity.isSelected()) {
//			newGraph = SuperPosition.calculateSuperposition(graphs, selectedAttribute, nodeColor, 0, 0,
//					super_OpacitySlider.getValue());
//		} else {
//			MainFrame.getInstance().createInternalFrame("javax.swing.JSplitPane", MainFrame.getInstance().getActiveEditorSession(), isSelectionListener());
//		}
		newGraph = SuperPosition.calculateSuperposition(graphs, selectedAttribute, nodeColor,
				super_DistanceSlider.getValue(), super_DegreeSlider.getValue(), super_OpacitySlider.getValue());
		MainFrame.getInstance().showGraph(newGraph, new ActionEvent(newGraph, 1, "Super Position Graph"));

	}

	private void DifferenceClicked(boolean JuxtaEnabled) {
		if (JuxtaEnabled) {
			Difference.calcJuxtaEcplicit(graphs, selectedAttribute, nodeColor, edgeColor);
//			Stack(true);
		} else {
			Graph newGraph = Difference.calcSuperExplicit(graphs, selectedAttribute, nodeColor, edgeColor,selectedUnOverlap);
			MainFrame.getInstance().showGraph(newGraph, new ActionEvent(newGraph, 1, "Difference Graph"));
			GraphHelper.issueCompleteRedrawForActiveView();
			View activview = MainFrame.getInstance().getActiveSession().getActiveView();
			Collection graphElements = MainFrame.getInstance().getActiveSession().getActiveView().getGraph().getGraphElements();// assuming this is the method that returns the collection

			for (Object element : graphElements) {
			    // do something with element
			    activview.repaint((GraphElement) element);
			}
		}
	}

	private void Stack(String position) {

//		Stack the Frames, Horizontal or Vertically
		Dimension desktopdim = MainFrame.getInstance().getDesktop().getSize();
		int number = getOpenFrameCnt(), cnt = 0;
		if (position.equals("Horizontal")) {
//			stack Horizontally
			if (number == 0)
				number = 1;
			for (JInternalFrame jf : MainFrame.getInstance().getDesktop().getAllFrames()) {
				try {
					jf.setMaximum(false);
					jf.setSelected(true);
					ZoomFitChangeComponent.zoomRegion(false);
				} catch (PropertyVetoException e) {
				}
				jf.setBounds(desktopdim.width * (cnt++) / number, 0, desktopdim.width / number, desktopdim.height);
			}
		} else {
//			Stack Vertically
			for (JInternalFrame jf : MainFrame.getInstance().getDesktop().getAllFrames()) {
				try {
					jf.setMaximum(false);
					jf.setSelected(true);
					ZoomFitChangeComponent.zoomRegion(false);
				} catch (PropertyVetoException e) {
				}
				jf.setBounds(0, desktopdim.height * (cnt++) / number, desktopdim.width, desktopdim.height / number);
			}
		}

		JInternalFrame[] jf = MainFrame.getInstance().getDesktop().getAllFrames();
		try {
			jf[1].setSelected(true);
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private int getOpenFrameCnt() {
		int res = 0;
		for (JInternalFrame jf : MainFrame.getInstance().getDesktop().getAllFrames()) {
			if (!jf.isIcon())
				res++;
		}
		return res;
	}

	/**
	 * For demonstration purposes this tab listens also to session changes to
	 * demonstrate how you can use graphlisteners. The problem here is that a
	 * graphlistener has to be registered for the graph you want to listen, and the
	 * session tracks which graph is the actually viewed graph. If this graph
	 * changes, we have to unregister the graphlistener from the old graph and have
	 * to register the new graph, in order to be able to listen to graphevents.
	 */
	public void sessionChanged(Session s) {
		if (s != null) {
			if (graph != null) {
				try {
					graph.getListenerManager().removeGraphListener(this);
				} catch (ListenerNotFoundException e) {
					ErrorMsg.addErrorMessage(e);
				}
			}

			graph = s.getGraph();
			graph.getListenerManager().addDelayedGraphListener(this);
		} else
			graph = null; // important, because if you don't free sessions,
		// views or graphs you will get a memory leak
	}

	public void sessionDataChanged(Session s) {
		System.out.println("SessionDataChanged" + s);
		//

	}

	public void postEdgeAdded(GraphEvent e) {
		System.out.println("SessionDataChanged" + e);

		//

	}

	public void postEdgeRemoved(GraphEvent e) {
		System.out.println("SessionDataChanged" + e);

		//

	}

	public void postGraphCleared(GraphEvent e) {
		System.out.println("SessionDataChanged" + e);

		//

	}

	/**
	 * As you can see, if a graph is open, every time a node is added we get a
	 * printout.
	 */
	public void postNodeAdded(GraphEvent e) {
		MainFrame.showMessage("Node added!", MessageType.INFO);
	}

	public void postNodeRemoved(GraphEvent e) {
		//

	}

	public void preEdgeAdded(GraphEvent e) {
		//

	}

	public void preEdgeRemoved(GraphEvent e) {
		//

	}

	public void preGraphCleared(GraphEvent e) {
		//

	}

	public void preNodeAdded(GraphEvent e) {
		//

	}

	public void preNodeRemoved(GraphEvent e) {
		//

	}

	/**
	 * Transactions can be used to bundle graph-changes and refresh the view
	 * afterwards. Usually you call
	 * <p>
	 * <code>view.getGraph().getListenerManager().transactionStarted(redrawbt);</code>
	 * <p>
	 * do your stuff like attributes changing and then
	 * <p>
	 * <code>view.getGraph().getListenerManager().transactionFinished(redrawbt);</code>
	 * <p>
	 * Now you can check what happened and react to that. For an implementation for
	 * a view see the method in {@link GraffitiView}.
	 */
	public void transactionFinished(TransactionEvent e, BackgroundTaskStatusProviderSupportingExternalCall status) {
		//

	}

	public void transactionStarted(TransactionEvent e) {
		//

	}

	/**
	 * If you want to listen to Selection events then (for an InspectorTab) you have
	 * to implement the {@link SelectionListener} interface and overwrite the
	 * <code>isSelectionListener</code> class and the tab will automatically be
	 * registered. All other objects have to be manually registered with
	 * <code>MainFrame.getInstance().addSelectionListener(this);</code>
	 */
	public void selectionChanged(SelectionEvent e) {
		//

	}

	public void selectionListChanged(SelectionEvent e) {
		//

	}

	@Override
	public boolean isSelectionListener() {
		return true;
	}

}
