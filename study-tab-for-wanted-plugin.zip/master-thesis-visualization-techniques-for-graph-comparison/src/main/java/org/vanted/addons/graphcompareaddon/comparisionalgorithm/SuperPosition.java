package org.vanted.addons.graphcompareaddon.comparisionalgorithm;

import org.AttributeHelper;
import java.util.List;
import org.graffiti.graph.Graph;
import org.graffiti.graph.Node;

import de.ipk_gatersleben.ag_nw.graffiti.GraphHelper;

import org.graffiti.event.ListenerManager;
import org.graffiti.graph.AdjListGraph;
import org.graffiti.graph.Edge;

import java.awt.Color;
import java.awt.geom.Point2D;

public class SuperPosition {

	private static Graph resultGraph;

	public SuperPosition() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Calculates the superposition of two graphs, updating the position and color
	 * of nodes with the same label attribute.
	 * 
	 * @param graphs       an array of two Graph objects to compare
	 * @param selAttribute the selected attribute for node labels
	 * @param selColor     the selected color for nodes with matching label
	 *                     attribute
	 * @return a new Graph object with the superposition of the two input graphs
	 */

	public static Graph calculateSuperposition(Graph[] graphs, String selAttribute, Color selColor, int distance,
			int degree, int opacity) {
		// Clear any previous result graph
		if (resultGraph != null) {
		    resultGraph.clear();
		}
		// Create a new result graph and add the two input graphs to it
		resultGraph = new AdjListGraph(new ListenerManager());
		resultGraph.addGraph(graphs[0]);
		resultGraph.addGraph(graphs[1]);

		// Get a list of all nodes in the result graph
		List<Node> allNodes = resultGraph.getNodes();

		// Double for loop to check for duplicate nodes
		for (int i = 0; i < allNodes.size(); i++) {
			for (int j = i + 1; j < allNodes.size(); j++) {
				String originNodeLabel = getLabel(selAttribute, allNodes.get(i));
				String duplicateNodeLabel = getLabel(selAttribute, allNodes.get(j));
				// If nodes have the same label attribute, update the position and color of the
				// duplicate node
				AttributeHelper.setOpacity(allNodes.get(i), opacity*0.01);
				AttributeHelper.setOpacity(allNodes.get(j), opacity*0.01);
				if (originNodeLabel.equalsIgnoreCase(duplicateNodeLabel)) {
//					AttributeHelper.setFillColor(allNodes.get(i), selColor);

					Point2D position = AttributeHelper.getPosition(allNodes.get(j));
					double radians = Math.toRadians(degree);
					double dx = distance * Math.sin(radians);
					double dy = distance * Math.cos(radians); 

					position.setLocation(position.getX() + dx, position.getY() - dy); 

					allNodes.get(i).setViewID(99);
					AttributeHelper.setPosition(allNodes.get(i), position);
				}

			}

		}
		
		List<Edge> allEdges = (List) resultGraph.getEdges();
		
		for (int i = 0; i < allEdges.size(); i++) {
			for (int j = i + 1; j < allEdges.size(); j++) {
				AttributeHelper.setOpacity(allEdges.get(j), opacity*0.01);
				AttributeHelper.setOpacity(allEdges.get(j), opacity*0.01);
				String originEdgeSource = getLabel("label", allEdges.get(i).getSource());
				String originEdgeTarget = getLabel("label", allEdges.get(i).getTarget());
				String duplicateEdgeSource = getLabel("label", allEdges.get(j).getSource());
				String duplicateEdgeTarget = getLabel("label", allEdges.get(j).getTarget());
				if (originEdgeSource.equals(duplicateEdgeSource) && originEdgeTarget.equals(duplicateEdgeTarget)) {
					addBend(allEdges.get(i),allEdges.get(j),10);

				}
			}
		}
		return resultGraph;
	}

	public static String getLabel(String selAttribute, Node node) {
		if (selAttribute.equals("label")) {
			return AttributeHelper.getLabel(node, null);
		} else {
			return (String) AttributeHelper.getAttribute(node, "identifier").getValue().toString();
		}
	}
	
    public static void addBend(Edge originEdge, Edge duplicateEdge, double delta) {
        // Get the start and end positions of the origin edge
        Point2D startPositionOrigin = AttributeHelper.getPosition(originEdge.getSource());
        Point2D endPositionOrigin = AttributeHelper.getPosition(originEdge.getTarget());

        // Calculate the midpoint
        double x_m = (startPositionOrigin.getX() + endPositionOrigin.getX()) / 2;
        double y_m = (startPositionOrigin.getY() + endPositionOrigin.getY()) / 2;

        // Calculate the slope of the original edge
        double m = (endPositionOrigin.getY() - startPositionOrigin.getY()) /
                   (endPositionOrigin.getX() - startPositionOrigin.getX());

        // Find the perpendicular slope
        double m_p;
        if (m == 0) {
            m_p = Double.POSITIVE_INFINITY; // vertical line
        } else {
            m_p = -1 / m;
        }

        // Calculate the change in x and y using the offset delta
        double deltaX, deltaY;
        if (Double.isInfinite(m_p)) {
            deltaX = 0;
            deltaY = delta;
        } else {
            deltaX = Math.sqrt(delta * delta / (1 + m_p * m_p));
            deltaY = m_p * deltaX;
        }

        // Calculate the two new bend positions
        double x1 = x_m + deltaX;
        double y1 = y_m + deltaY;
        
        double x2 = x_m - deltaX;
        double y2 = y_m - deltaY;

        // Add the bends to the original and duplicate edges
        AttributeHelper.addEdgeBend(originEdge, x1, y1);
        AttributeHelper.addEdgeBend(duplicateEdge, x2, y2);
		AttributeHelper.setShape(originEdge, "org.graffiti.plugins.views.defaults.SmoothLineEdgeShape");
		AttributeHelper.setShape(duplicateEdge, "org.graffiti.plugins.views.defaults.SmoothLineEdgeShape");

    }


}