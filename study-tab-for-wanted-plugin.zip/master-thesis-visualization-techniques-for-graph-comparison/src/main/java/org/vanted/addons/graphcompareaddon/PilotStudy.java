/*************************************************************************************
 * The Exemplary Add-on is (c) 2008-2011 Plant Bioinformatics Group, IPK Gatersleben,
 * http://bioinformatics.ipk-gatersleben.de
 * The source code for this project, which is developed by our group, is
 * available under the GPL license v2.0 available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html. By using this
 * Add-on and VANTED you need to accept the terms and conditions of this
 * license, the below stated disclaimer of warranties and the licenses of
 * the used libraries. For further details see license.txt in the root
 * folder of this project.
 ************************************************************************************/
package org.vanted.addons.graphcompareaddon;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Set;
import java.util.UUID;

import javax.swing.AbstractButton;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.BackgroundTaskStatusProviderSupportingExternalCall;
import org.ErrorMsg;
import org.graffiti.editor.MainFrame;
import org.graffiti.editor.MessageType;
import org.graffiti.event.GraphEvent;
import org.graffiti.event.GraphListener;
import org.graffiti.event.ListenerNotFoundException;
import org.graffiti.event.TransactionEvent;
import org.graffiti.graph.Graph;
import org.graffiti.plugin.inspector.InspectorTab;
import org.graffiti.plugin.view.View;
import org.graffiti.plugin.view.ViewListener;
import org.graffiti.plugins.views.defaults.GraffitiView;
import org.graffiti.selection.SelectionEvent;
import org.graffiti.selection.SelectionListener;
import org.graffiti.session.EditorSession;
import org.graffiti.session.Session;
import org.graffiti.session.SessionListener;
import org.vanted.addons.graphcompareaddon.pilot_study.ResponseLogger;

import de.ipk_gatersleben.ag_nw.graffiti.plugins.gui.editing_tools.CloseAllWindows;

/**
 *
 * AddonTab class represents a GUI panel that contains various components for
 * visualizing and manipulating graphs. It loads two graph files and displays
 * them using MainFrame. The panel contains components for setting node and edge
 * colors, selecting node attributes, stacking and superimposing graphs, and
 * performing difference operations. It also provides a tabbed interface for
 * organizing different types of operations.
 *
 * @author Aredio Vani
 */
public class PilotStudy extends InspectorTab
		implements ViewListener, SessionListener, GraphListener, SelectionListener {

	private File graph1;
	private File graph2;
	private CardLayout cardLayout = new CardLayout();
	private JPanel cards = new JPanel(cardLayout);
	private JLabel statusText;
	private String mainGraph;
	private CloseAllWindows closeAllWindows;
	private JLabel studyStatus = new JLabel();
	private static final long serialVersionUID = 1L;

	private JPanel welcomePanel;
	private JLabel welcomeLabel;
	private JLabel welcomeUIDlabel;
	private JTextField welcomeUIDinput;
	private JComboBox<String> orderSelection;
	private JButton startButton;

	// it is dangerous to save a graph. if you need it be sure to release the
	// reference on null-sessions or views
	private Graph graph;
	private Graph[] graphs = new Graph[2];

	private long currTime;
	private ResponseLogger logger;
	private String[] conditionOrders = { "JSD", "JDS", "SJD", "SDJ", "DSJ", "DJS" };
	private String selectedConditionOrder = "";
	private int repetition = 1;
	private int currentCondition = 0;
	private int currentPosition = 1;

	/**
	 * Please refer to the implementation of InspectorTab to see the inherited
	 * methods and fields.
	 */
	public PilotStudy() {
		// Load Graphs
		setLayout(new BorderLayout());

		// Welcome panel
		// Initialization Section
		JPanel cards = new JPanel(new CardLayout());
		CardLayout cardLayout = (CardLayout) cards.getLayout();

		// Welcome Panel
		welcomePanel = new JPanel();
		welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
		welcomeLabel = new JLabel("Welcome to the Experiment!");
//		welcomeUIDlabel = new JLabel("User ID: ");
//		welcomeUIDinput = new JTextField(20);
//		welcomeUIDinput.setMaximumSize(new Dimension(200, 20));
		startButton = new JButton("Start");
		orderSelection = new JComboBox<>(conditionOrders);
		orderSelection.setPreferredSize(new Dimension(200, 30)); // Set your preferred width and height
		orderSelection.setMaximumSize(new Dimension(200, 30));

		welcomePanel.add(welcomeLabel);
//		welcomePanel.add(welcomeUIDlabel);
//		welcomePanel.add(welcomeUIDinput);
		welcomePanel.add(orderSelection);
		welcomePanel.add(startButton);

		// Welcome Panel Listener
		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String UID = UUID.randomUUID().toString();
				logger = new ResponseLogger(UID);
				currTime = System.currentTimeMillis();
				String formattedDate = dateFormater(currTime, "yyyy-MM-dd HH:mm:ss");
				selectedConditionOrder = (String) orderSelection.getSelectedItem().toString();

				logger.logResponse("Start of log of new experiment");
				logger.logResponse("User ID: " + UID);
				logger.logResponse("Date of expermient: " + formattedDate);
				logger.logResponse("Condition Order: " + selectedConditionOrder);
				logger.logResponse("");

				cardLayout.show(cards, "question1");
				showCondition(currentPosition, 1, (char) selectedConditionOrder.charAt(currentCondition), 1);
//				selectedConditionOrder = selectedConditionOrder.substring(1);

			}
		});

		// Question 1
		JPanel question1Panel = new JPanel();
		question1Panel.setLayout(new BoxLayout(question1Panel, BoxLayout.PAGE_AXIS));
		JLabel question1Label = new JLabel(
				"<html><h2>In which graph does the highlighted node have a higher sum of edge weights?</h2></html>");
		JLabel question1Desc = new JLabel(
				"<html><p>In this question you are tasked to sum up the weight of all the edges of the highlighted node. \r\n"
						+ "Make the calculations on both graphs and select the option with the higher value.</p></html>");
		ButtonGroup q1Group = new ButtonGroup();
		JRadioButton q1Option1 = new JRadioButton("Graph 1 (blue)");
		JRadioButton q1Option2 = new JRadioButton("Graph 2 (orange)");
		JRadioButton q1Option3 = new JRadioButton("Same in both");
		q1Group.add(q1Option1);
		q1Group.add(q1Option2);
		q1Group.add(q1Option3);
		JButton q1NextButton = new JButton("Next");
		q1NextButton.setEnabled(false);
		q1Option1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q1NextButton.setEnabled(true);
			}
		});

		q1Option2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q1NextButton.setEnabled(true);
			}
		});

		q1Option3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q1NextButton.setEnabled(true);
			}
		});
		question1Panel.add(question1Label);
		question1Panel.add(q1Option1);
		question1Panel.add(q1Option2);
		question1Panel.add(q1Option3);
		question1Panel.add(q1NextButton);
		question1Panel.add(question1Desc);

		// Question 1 Listener
		q1NextButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String selectedText = Collections.list(q1Group.getElements()).stream()
						.filter(AbstractButton::isSelected).map(AbstractButton::getText).findFirst()
						.orElse("None Selected");
				long timeTaken = System.currentTimeMillis() - currTime;

				logger.logResponse("Question:1 - Condition:" + selectedConditionOrder.charAt(currentCondition)
						+ " - Repetition: " + repetition);
				logger.logResponse("Answer: " + selectedText);
				logger.logResponse("Time Taken: " + dateFormater(timeTaken, "mm:ss"));
				logger.logResponse(" ");

				q1Group.clearSelection();
				currTime = System.currentTimeMillis();
				q1NextButton.setEnabled(false);

				if (repetition == 3 && currentCondition == 2) {
					repetition = 1;
					currentCondition = 0;
					currentPosition = 1;
					showCondition(currentPosition, 2, selectedConditionOrder.charAt(currentCondition), repetition);
					cardLayout.show(cards, "question2");
				} else if (repetition == 3) {
					repetition = 1;
					currentCondition++;
					currentPosition++;
					showCondition(currentPosition, 1, selectedConditionOrder.charAt(currentCondition), repetition);
				} else if (repetition < 3) {
					repetition++;
					showCondition(currentPosition, 1, selectedConditionOrder.charAt(currentCondition), repetition);
				}

			}
		});

		// Question 2
		JPanel question2Panel = new JPanel();
		question2Panel.setLayout(new BoxLayout(question2Panel, BoxLayout.PAGE_AXIS));
		JLabel question2Label = new JLabel();
		question2Label.setText(
				"<html><h2>How many edges connected to the highlighted nodes are found in both graphs?</h2></html>");
		JLabel question2Desc = new JLabel();
		question2Desc.setText(
				"<html><p> Determine the number of edges that these highlighted nodes share across both graphs."
						+ " Note that the weight of the edges is not relevant for this task."
						+ "When an edge is present in both count as 1</p></html>");

		JTextField q2AnswerField = new JTextField(10);
		q2AnswerField.setMaximumSize((new Dimension(200, 30)));
		JButton q2SubmitButton = new JButton("Submit");
		q2SubmitButton.setEnabled(false);
		q2AnswerField.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				updateButtonState();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				updateButtonState();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				updateButtonState();
			}

			private void updateButtonState() {
				// Enable the button if there is any text in the q2AnswerField
				q2SubmitButton.setEnabled(!q2AnswerField.getText().isEmpty());
			}
		});
		question2Panel.add(question2Label);
		question2Panel.add(q2AnswerField);
		question2Panel.add(q2SubmitButton);
		question2Panel.add(question2Desc);
		// Question 2 Listener
		q2SubmitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q2SubmitButton.setEnabled(true);
				String selectedText = q2AnswerField.getText();
				long timeTaken = System.currentTimeMillis() - currTime;

				logger.logResponse("Question:2 - Condition:" + selectedConditionOrder.charAt(currentCondition)
						+ " - Repetition: " + repetition);
				logger.logResponse("Answer: " + selectedText);
				logger.logResponse("Time Taken: " + dateFormater(timeTaken, "mm:ss"));
				logger.logResponse(" ");

				q2AnswerField.setText("");
				currTime = System.currentTimeMillis();

				if (repetition == 3 && currentCondition == 2) {
					repetition = 1;
					currentCondition = 0;
					currentPosition = 1;
					showCondition(currentPosition, 3, selectedConditionOrder.charAt(currentCondition), repetition);
					cardLayout.show(cards, "question3");
				} else if (repetition == 3) {
					repetition = 1;
					currentCondition++;
					currentPosition++;
					showCondition(currentPosition, 2, selectedConditionOrder.charAt(currentCondition), repetition);
				} else if (repetition < 3) {
					repetition++;
					showCondition(currentPosition, 2, selectedConditionOrder.charAt(currentCondition), repetition);
				}

			}
		});

		// Question 3
		JPanel question3Panel = new JPanel();
		question3Panel.setLayout(new BoxLayout(question3Panel, BoxLayout.Y_AXIS));
		JLabel question3Label = new JLabel();
		question3Label.setText(
				"<html><h2>Identify the graph in which the shortest path between the highlighted nodes has the smallest value.</h2></html>");
		JLabel question3Desc = new JLabel();
		question3Desc.setText(""
				+ "<html><p>The shortest path in a network refers to the route that connects two nodes using the fewest edges or the least total weight. Consider a scenario where you want to travel from point A to point B. If you have options like the path A-C-B or A-D-E-B, you would select the one with fewer stops or a lower cumulative distance, typically A-C-B. In this case, both graphs contain identical paths. Once you've identified this path, calculate the total weight of the edges along the path. Finally, select the graph where the sum of these weights is the smallest.</p></html>");
		ButtonGroup q3Group = new ButtonGroup();
		JRadioButton q3Option1 = new JRadioButton("Graph 1 (blue)");
		JRadioButton q3Option2 = new JRadioButton("Graph 2 (orange)");
		JRadioButton q3Option3 = new JRadioButton("Same in both");
		q3Group.add(q3Option1);
		q3Group.add(q3Option2);
		q3Group.add(q3Option3);
		JButton q3NextButton = new JButton("Next");
		q3NextButton.setEnabled(false);
		q3Option1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q3NextButton.setEnabled(true);
			}
		});

		q3Option2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q3NextButton.setEnabled(true);
			}
		});

		q3Option3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q3NextButton.setEnabled(true);
			}
		});
		question3Panel.add(question3Label);
		question3Panel.add(q3Option1);
		question3Panel.add(q3Option2);
		question3Panel.add(q3Option3);
		question3Panel.add(q3NextButton);
		question3Panel.add(question3Desc);

		// Question 3 Listener
		q3NextButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				q3NextButton.setEnabled(true);
				String selectedText = Collections.list(q3Group.getElements()).stream()
						.filter(AbstractButton::isSelected).map(AbstractButton::getText).findFirst()
						.orElse("None Selected");
				long timeTaken = System.currentTimeMillis() - currTime;

				logger.logResponse("Question:3 - Condition:" + selectedConditionOrder.charAt(currentCondition)
						+ " - Repetition: " + repetition);
				logger.logResponse("Answer: " + selectedText);
				logger.logResponse("Time Taken: " + dateFormater(timeTaken, "mm:ss"));
				logger.logResponse(" ");

				q3Group.clearSelection();
				currTime = System.currentTimeMillis();
				q3NextButton.setEnabled(false);

				if (repetition == 3 && currentCondition == 2) {
					closeFrame();
					cardLayout.show(cards, "gb");
					long endTime = System.currentTimeMillis();
					currTime = System.currentTimeMillis();
					String formattedDate = dateFormater(currTime, "yyyy-MM-dd HH:mm:ss");

					logger.logResponse("End of log of new experiment");
					logger.logResponse("End Time: " + formattedDate);
				} else if (repetition == 3) {
					repetition = 1;
					currentCondition++;
					currentPosition++;
					showCondition(currentPosition, 3, selectedConditionOrder.charAt(currentCondition), repetition);
				} else if (repetition < 3) {
					repetition++;
					showCondition(currentPosition, 3, selectedConditionOrder.charAt(currentCondition), repetition);
				}

			}
		});

		question3Panel.add(question3Label);
		question3Panel.add(q3Option1);
		question3Panel.add(q3Option2);
		question3Panel.add(q3Option3);
		question3Panel.add(q3NextButton);

		JPanel gbPanel = new JPanel();
		gbPanel.setLayout(new BoxLayout(gbPanel, BoxLayout.Y_AXIS));
		JLabel gbLabel = new JLabel();
		gbLabel.setText("<html><h1> The experiment has conculded, thank you for participating.</h1></html>");

		gbPanel.add(gbLabel);

		// Add panels to card layout
		cards.add(welcomePanel, "welcome");
		cards.add(question1Panel, "question1");
		cards.add(question2Panel, "question2");
		cards.add(question3Panel, "question3");
		cards.add(gbPanel, "gb");

		studyStatus.setForeground(Color.red);
		add(studyStatus, BorderLayout.NORTH);

		add(cards, BorderLayout.CENTER);
		validate();

	}

	private void showCondition(int position, int question, char vis, int repetition) {

		studyStatus.setText("Position: " + position + "| Question: " + question + " | Condition: " + vis
				+ " | Repetiton: " + repetition);
		closeFrame();

		if (vis == 'J') {
			graph1 = new File("./src/main/resources/graphs/final/J_P" + position + "_Q" + question + "_R" + repetition
					+ "_graph1.gml");
			graph2 = new File("./src/main/resources/graphs/final/J_P" + position + "_Q" + question + "_R" + repetition
					+ "_graph2.gml");
			MainFrame.getInstance().loadGraph(graph1);
			MainFrame.getInstance().loadGraph(graph2);

		} else if (vis == 'S') {
			graph1 = new File(
					"./src/main/resources/graphs/final/S_P" + position + "_Q" + question + "_R" + repetition + ".gml");
			MainFrame.getInstance().loadGraph(graph1);

		} else {
			graph1 = new File(
					"./src/main/resources/graphs/final/D_P" + position + "_Q" + question + "_R" + repetition + ".gml");
			MainFrame.getInstance().loadGraph(graph1);

		}
		Stack();

	}

	public void closeFrame() {
		Set<Session> allSesh = MainFrame.getSessions();
		for (Session sesh : allSesh) {
			sesh.close();
			sesh.getGraph().setModified(false);

		}
		Set<EditorSession> allSesh2 = MainFrame.getInstance().getEditorSessions();
		for (Session sesh : allSesh2) {
			sesh.close();
		}

		JInternalFrame[] frames = MainFrame.getInstance().getDesktop().getAllFrames();

		// Iterate through frames and close them
		for (JInternalFrame frame : frames) {
			frame.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
			try {
				frame.setClosed(true);
			} catch (Exception ex) {
				System.out.println("getMessage(): " + ex.getMessage());
			}
		}

	}

	@Override
	public String getName() {
		return getTitle();
	}

	/**
	 * Don't forget to set the title, otherwise the tab won't be shown.
	 */
	@Override
	public String getTitle() {
		return "PILOT-STUDY";
	}

	/**
	 * Vanted will ask every time all tabs, when a view changes, if this tab wants
	 * to be hidden or not.
	 */
	@Override
	public boolean visibleForView(View v) {

		return true;

	}

	/**
	 * For demonstration purposes this tab listens to a view change and just prints
	 * out the view and creates an exemplary {@FolderPanel} .
	 */
	@Override
	public void viewChanged(View newView) {

	}

	private void Stack() {

//		Stack the Frames, Horizontal or Vertically
		Dimension desktopdim = MainFrame.getInstance().getDesktop().getSize();
		int number = getOpenFrameCnt(), cnt = 0;
//			stack Horizontally
		if (number == 0)
			number = 1;
		for (JInternalFrame jf : MainFrame.getInstance().getDesktop().getAllFrames()) {
			try {
				jf.setMaximum(false);
				jf.setSelected(false);

			} catch (PropertyVetoException e) {
			}
//			ZoomFitChangeComponent.zoomRegion(true);
			jf.setBounds(desktopdim.width * (cnt++) / number, 0, desktopdim.width / number, desktopdim.height);
//			ZoomFitChangeComponent.zoomIn();
		}

	}

	private int getOpenFrameCnt() {
		int res = 0;
		for (JInternalFrame jf : MainFrame.getInstance().getDesktop().getAllFrames()) {
			if (!jf.isIcon())
				res++;
		}
		return res;
	}

	private String dateFormater(long currTime, String format) {
		Date currentDate = new Date(currTime);
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(currentDate);

	}

	/**
	 * For demonstration purposes this tab listens also to session changes to
	 * demonstrate how you can use graphlisteners. The problem here is that a
	 * graphlistener has to be registered for the graph you want to listen, and the
	 * session tracks which graph is the actually viewed graph. If this graph
	 * changes, we have to unregister the graphlistener from the old graph and have
	 * to register the new graph, in order to be able to listen to graphevents.
	 */
	@Override
	public void sessionChanged(Session s) {
		if (s != null) {
			if (graph != null) {
				try {
					graph.getListenerManager().removeGraphListener(this);
				} catch (ListenerNotFoundException e) {
					ErrorMsg.addErrorMessage(e);
				}
			}

			graph = s.getGraph();
			graph.getListenerManager().addDelayedGraphListener(this);
		} else
			graph = null; // important, because if you don't free sessions,
		// views or graphs you will get a memory leak

	}

	@Override
	public void sessionDataChanged(Session s) {
		System.out.println("SessionDataChanged" + s);
		//

	}

	@Override
	public void postEdgeAdded(GraphEvent e) {
		System.out.println("SessionDataChanged" + e);

		//

	}

	@Override
	public void postEdgeRemoved(GraphEvent e) {
		System.out.println("SessionDataChanged" + e);

		//

	}

	@Override
	public void postGraphCleared(GraphEvent e) {
		System.out.println("SessionDataChanged" + e);

		//

	}

	/**
	 * As you can see, if a graph is open, every time a node is added we get a
	 * printout.
	 */
	@Override
	public void postNodeAdded(GraphEvent e) {
		MainFrame.showMessage("Node added!", MessageType.INFO);
	}

	@Override
	public void postNodeRemoved(GraphEvent e) {
		//

	}

	@Override
	public void preEdgeAdded(GraphEvent e) {
		//

	}

	@Override
	public void preEdgeRemoved(GraphEvent e) {
		//

	}

	@Override
	public void preGraphCleared(GraphEvent e) {
		//

	}

	@Override
	public void preNodeAdded(GraphEvent e) {
		//

	}

	@Override
	public void preNodeRemoved(GraphEvent e) {
		//

	}

	/**
	 * Transactions can be used to bundle graph-changes and refresh the view
	 * afterwards. Usually you call
	 * <p>
	 * <code>view.getGraph().getListenerManager().transactionStarted(redrawbt);</code>
	 * <p>
	 * do your stuff like attributes changing and then
	 * <p>
	 * <code>view.getGraph().getListenerManager().transactionFinished(redrawbt);</code>
	 * <p>
	 * Now you can check what happened and react to that. For an implementation for
	 * a view see the method in {@link GraffitiView}.
	 */
	@Override
	public void transactionFinished(TransactionEvent e, BackgroundTaskStatusProviderSupportingExternalCall status) {
		//

	}

	@Override
	public void transactionStarted(TransactionEvent e) {
		//

	}

	/**
	 * If you want to listen to Selection events then (for an InspectorTab) you have
	 * to implement the {@link SelectionListener} interface and overwrite the
	 * <code>isSelectionListener</code> class and the tab will automatically be
	 * registered. All other objects have to be manually registered with
	 * <code>MainFrame.getInstance().addSelectionListener(this);</code>
	 */
	@Override
	public void selectionChanged(SelectionEvent e) {
		//

	}

	@Override
	public void selectionListChanged(SelectionEvent e) {
		//

	}

	@Override
	public boolean isSelectionListener() {
		return true;
	}

}
