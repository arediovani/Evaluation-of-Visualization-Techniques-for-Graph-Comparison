package org.vanted.addons.graphcompareaddon.comparisionalgorithm;

import java.awt.Color;
import java.awt.Label;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.AttributeHelper;
import org.graffiti.graph.Edge;
import org.graffiti.event.ListenerManager;
import org.graffiti.graph.AdjListGraph;
import org.graffiti.graph.Graph;
import org.graffiti.graph.Node;
import org.graffiti.graphics.EdgeLabelAttribute;

import de.ipk_gatersleben.ag_nw.graffiti.GraphHelper;

public class Difference {

	private static Graph resultGraph;

	public Difference() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Calculates the super explicit graph from an array of two graphs, based on the
	 * specified attribute.
	 * 
	 * @param graphs       An array of two graphs.
	 * @param selAttribute The attribute to use for identifying nodes that should be
	 *                     merged.
	 * @param nodeSelColor The color to use for merged nodes.
	 * @param edgeSelColor The color to use for merged edges.
	 * @return A new graph that represents the super explicit graph of the input
	 *         graphs.
	 */
	public static Graph calcSuperExplicit(Graph[] graphs, String selAttribute, Color nodeSelColor, Color edgeSelColor,String UnOverlap) {
		// Check if resultGraph is null, and clear it if it's not
		if (!(resultGraph == null)) {
			resultGraph.clear();
		}

		// Create a new AdjListGraph and add the first two graphs to it
		resultGraph = new AdjListGraph(new ListenerManager());
		resultGraph.addGraph(graphs[0]);
		resultGraph.addGraph(graphs[1]);

		// Get all nodes and edges in the new graph
		List<Node> allNodes = resultGraph.getNodes();
		List<Edge> allEdges = (List) resultGraph.getEdges();

		// Loop through all pairs of nodes in the new graph
		for (int i = 0; i < allNodes.size(); i++) {
			for (int j = i + 1; j < allNodes.size(); j++) {
				Node originNode = allNodes.get(i);
				Node duplicateNode = allNodes.get(j);

				// Check if the two nodes have the same label for the selected attribute
				if (getLabel(selAttribute, originNode).equals(getLabel(selAttribute, duplicateNode))) {
					// Set the fill color of the original node to nodeSelColor
					AttributeHelper.setFillColor(originNode, nodeSelColor);

					// Get all edges that originate from the duplicate node
					Collection<Edge> edgesfromDuplicate = duplicateNode.getEdges();
					// Loop through each of those edges
					for (Edge edge : edgesfromDuplicate) {
						// If the edge starts at the duplicate node, set its source to the original node
						if (edge.getSource().equals(duplicateNode)) {
							edge.setSource(originNode);
						}
						// If the edge ends at the duplicate node, set its target to the original node
						else {
							edge.setTarget(originNode);
						}
					}
					// Delete the duplicate node from the graph
					resultGraph.deleteNode(duplicateNode);
				}
			}
		}

		// Loop through all pairs of edges in the new graph
		for (int i = 0; i < allEdges.size(); i++) {
			for (int j = i + 1; j < allEdges.size(); j++) {
				Edge originEdge = allEdges.get(i);
				Edge duplicateEdge = allEdges.get(j);

				// Check if the two edges have the same source and target nodes
				if (originEdge.getSource().equals(duplicateEdge.getSource())
						&& originEdge.getTarget().equals(duplicateEdge.getTarget())) {
					
					String label1 = (String) AttributeHelper.getAttribute(originEdge, "value").getValue().toString();
					String label2 = (String) AttributeHelper.getAttribute(duplicateEdge, "value").getValue().toString();
					int Intlabel1 = Integer.parseInt(label1);
					int Intlabel2 = Integer.parseInt(label2);
					
					if(Intlabel1==Intlabel2) {
						resultGraph.deleteEdge(duplicateEdge);
						AttributeHelper.setOutlineColor(originEdge, edgeSelColor);
					}else {
						switch (UnOverlap) {
			            case "Bend":
			                addBend(originEdge,duplicateEdge,10);
							break;
			            case "Concat":
							// Combine the labels with a slash and set the label of the original edge to the
							// new label
							AttributeHelper.setLabel(originEdge, label1 + "/" + label2);
							// Set the outline color of the original edge to edgeSelColor
							AttributeHelper.setOutlineColor(originEdge, edgeSelColor);

							// Delete the duplicate edge from the graph
							resultGraph.deleteEdge(duplicateEdge);
			                break;
			            case "Difference":
			                System.out.println("Performing Difference operation");
			                // Perform Difference operation logic here
			                break;
			            default:
			                System.out.println("Invalid operation");
			                // Handle invalid operation here
			        }
					}
			        
					// Get the labels of both edges

				}
			}
		}

		// Return the new graph with duplicate nodes and edges merged
		return resultGraph;
	}

	public static void calcJuxtaEcplicit(Graph[] graphs, String SelAttribute,Color nodeSelColor, Color edgeSelColor) {
		// Create a map to store node positions in the first graph
		Map<String, Point2D> nodePositions = new HashMap<>();
		for (Node node : graphs[0].getNodes()) {
			String label = getLabel(SelAttribute, node);
			if (label != null) {
				nodePositions.put(label, AttributeHelper.getPosition(node));
			}
		}

		// Loop through nodes in the second graph and update positions if a matching
		// node exists in the first graph
		for (Node node : graphs[1].getNodes()) {
			String label = getLabel(SelAttribute, node);
			if (label != null) {
				Point2D position = nodePositions.get(label);
				if (position != null) {
					AttributeHelper.setPosition(node, position);
				}

			}
		}

		// Loop through nodes in both graphs and set random positions for nodes that do
		// not exist in either graph
		Set<String> nodeLabels = new HashSet<>();
		for (Graph graph : graphs) {
			for (Node node : graph.getNodes()) {
				String label = getLabel(SelAttribute, node);
				if (label != null) {
					nodeLabels.add(label);
				}
			}
		}

		for (Graph graph : graphs) {
			for (Node node : graph.getNodes()) {
				String label = getLabel(SelAttribute, node);
				if (label != null && !nodePositions.containsKey(label)) {
					Set<Node> nodeNeighbours = node.getNeighbors();
					Double baryCenterX = 0.0;
					Double baryCenterY = 0.0;
					for (Node neighbourNode : nodeNeighbours) {
						baryCenterX += AttributeHelper.getPositionX(neighbourNode);
						baryCenterY += AttributeHelper.getPositionY(neighbourNode);
					}
					Point2D position = new Point2D.Double(baryCenterX / nodeNeighbours.size(),
							baryCenterY / nodeNeighbours.size());
					AttributeHelper.setPosition(node, position);
					nodePositions.put(label, position);
				}
			}
		}

		List<Node> allNodes = graphs[0].getNodes();
		allNodes.addAll(graphs[1].getNodes());
		List<Edge> allEdges = (List) graphs[0].getEdges();
		allEdges.addAll((List) graphs[1].getEdges());

		for (int i = 0; i < allNodes.size(); i++) {
			for (int j = i + 1; j < allNodes.size(); j++) {
				if (getLabel(SelAttribute, allNodes.get(i)).equals(getLabel(SelAttribute, allNodes.get(j)))) {
					AttributeHelper.setFillColor(allNodes.get(i), nodeSelColor);
					AttributeHelper.setFillColor(allNodes.get(j), nodeSelColor);
				}

			}

		}

		for (int i = 0; i < allEdges.size(); i++) {
			for (int j = i + 1; j < allEdges.size(); j++) {
				String originEdgeSource = getLabel(SelAttribute, allEdges.get(i).getSource());
				String originEdgeTarget = getLabel(SelAttribute, allEdges.get(i).getTarget());
				String duplicateEdgeSource = getLabel(SelAttribute, allEdges.get(j).getSource());
				String duplicateEdgeTarget = getLabel(SelAttribute, allEdges.get(j).getTarget());
				if (originEdgeSource.equals(duplicateEdgeSource) && originEdgeTarget.equals(duplicateEdgeTarget)) {
					AttributeHelper.setOutlineColor(allEdges.get(i), edgeSelColor);
					AttributeHelper.setOutlineColor(allEdges.get(j), edgeSelColor);
				}
			}
		}
	}

	public static String getLabel(String selAttribute, Node node) {
		if (selAttribute.equals("label")) {
			return AttributeHelper.getLabel(node, null);
		} else {
			return (String) AttributeHelper.getAttribute(node, "identifier").getValue().toString();
		}
	}

	
	   public static void addBend(Edge originEdge, Edge duplicateEdge, double delta) {
	        // Get the start and end positions of the origin edge
	        Point2D startPositionOrigin = AttributeHelper.getPosition(originEdge.getSource());
	        Point2D endPositionOrigin = AttributeHelper.getPosition(originEdge.getTarget());

	        // Calculate the midpoint
	        double x_m = (startPositionOrigin.getX() + endPositionOrigin.getX()) / 2;
	        double y_m = (startPositionOrigin.getY() + endPositionOrigin.getY()) / 2;

	        // Calculate the slope of the original edge
	        double m = (endPositionOrigin.getY() - startPositionOrigin.getY()) /
	                   (endPositionOrigin.getX() - startPositionOrigin.getX());

	        // Find the perpendicular slope
	        double m_p;
	        if (m == 0) {
	            m_p = Double.POSITIVE_INFINITY; // vertical line
	        } else {
	            m_p = -1 / m;
	        }

	        // Calculate the change in x and y using the offset delta
	        double deltaX, deltaY;
	        if (Double.isInfinite(m_p)) {
	            deltaX = 0;
	            deltaY = delta;
	        } else {
	            deltaX = Math.sqrt(delta * delta / (1 + m_p * m_p));
	            deltaY = m_p * deltaX;
	        }

	        // Calculate the two new bend positions
	        double x1 = x_m + deltaX;
	        double y1 = y_m + deltaY;
	        
	        double x2 = x_m - deltaX;
	        double y2 = y_m - deltaY;

	        // Add the bends to the original and duplicate edges
	        AttributeHelper.addEdgeBend(originEdge, x1, y1);
	        AttributeHelper.addEdgeBend(duplicateEdge, x2, y2);
			AttributeHelper.setShape(originEdge, "org.graffiti.plugins.views.defaults.SmoothLineEdgeShape");
			AttributeHelper.setShape(duplicateEdge, "org.graffiti.plugins.views.defaults.SmoothLineEdgeShape");

	        
	   }

}
