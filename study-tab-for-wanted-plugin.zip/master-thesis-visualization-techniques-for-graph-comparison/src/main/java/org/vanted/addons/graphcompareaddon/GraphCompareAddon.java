/*************************************************************************************
 * The Exemplary Add-on is (c) 2008-2011 Plant Bioinformatics Group, IPK Gatersleben,
 * http://bioinformatics.ipk-gatersleben.de
 * The source code for this project, which is developed by our group, is
 * available under the GPL license v2.0 available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html. By using this
 * Add-on and VANTED you need to accept the terms and conditions of this
 * license, the below stated disclaimer of warranties and the licenses of
 * the used libraries. For further details see license.txt in the root
 * folder of this project.
 ************************************************************************************/
package org.vanted.addons.graphcompareaddon;

import javax.swing.ImageIcon;

import org.AttributeHelper;
import org.ErrorMsg;
import org.graffiti.attributes.AttributeDescription;
import org.graffiti.attributes.StringAttribute;
import org.graffiti.editor.GravistoService;
import org.graffiti.plugin.algorithm.Algorithm;
import org.graffiti.plugin.gui.GraffitiComponent;
import org.graffiti.plugin.inspector.InspectorTab;
import org.graffiti.plugin.io.OutputSerializer;

import de.ipk_gatersleben.ag_nw.graffiti.plugins.addons.AddonAdapter;

/**
 * @author Hendrik Rohn Use {@link AddonAdapter} to indicate, that you are
 *         writing an addon. If an exception occurs during instantiation, a
 *         proper error message will be thrown and a standard addon icon will be
 *         used.
 */
public class GraphCompareAddon extends AddonAdapter {

	/**
	 * This class will automatically start all implemented Algorithms, views and
	 * other extensions written in your Add-on. A code formatting template
	 * (save_action_format.xml) is available in the "make" project of the VANTED
	 * CVS.
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void initializeAddon() {
		// registers a (number of) Tabs in the sidepanel, on which you may add
		// any Jcomponent you want to
		this.tabs = new InspectorTab[] { new AddonTab(),new PilotStudy() };


	}

	/**
	 * Here you may specify your own logo, which will appear in menus and tabs.
	 */
	@Override
	public ImageIcon getIcon() {
		try {
			ImageIcon icon = new ImageIcon(GravistoService.getResource(this.getClass(), "starspace", "png"));
			return icon;
		} catch (Exception e) {
			ErrorMsg.addErrorMessage(e);
			return super.getIcon();
		}
	}

}
