package org.vanted.addons.graphcompareaddon.pilot_study;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class ResponseLogger {

    private Path logFile;

    public ResponseLogger(String filename) {
        // Create a directory called "responses" if it doesn't exist
        Path directory = Path.of("responses");
        if (Files.notExists(directory)) {
            try {
                Files.createDirectory(directory);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Set the logFile path to be inside the "responses" directory
        this.logFile = directory.resolve(filename+"-answers.txt");
        
        try {
            if (Files.notExists(logFile)) {
                Files.createFile(logFile);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void logResponse(String response) {
        try (BufferedWriter writer = Files.newBufferedWriter(logFile, StandardOpenOption.APPEND)) {
            writer.write(response);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
