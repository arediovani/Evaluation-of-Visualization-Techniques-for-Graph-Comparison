package org.vanted.addons.graphcompareaddon.comparisionalgorithm;

import org.graffiti.graph.Graph;
import org.graffiti.graph.Node;
import java.util.Set;

import org.AttributeHelper;
import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class JuxtaPosition {
	/**
	 * Calculates the juxtaposition of nodes with the same label attribute between
	 * two graphs.
	 * 
	 * @param graphs       an array of two Graph objects to compare
	 * @param selAttribute the selected attribute for node labels
	 */
	public static void calculateJuxtaposition(Graph[] graphs, String selAttribute) {
		// Create a map to store the positions of nodes with the selected label
		// attribute from the first graph
		Map<String, Point2D> nodePositions = new HashMap<>();
		for (Node node : graphs[0].getNodes()) {
			String label = getLabel(selAttribute, node);
			// If the node has the selected label attribute, add its position to the map
			if (label != null) {
				nodePositions.put(label, AttributeHelper.getPosition(node));
			}
		}

		// Check nodes in the second graph with the selected label attribute and update
		// their positions to the ones in the first graph
		for (Node node : graphs[1].getNodes()) {
			String label = getLabel(selAttribute, node);
			if (label != null) {
				Point2D position = nodePositions.get(label);
				if (position != null) {
					AttributeHelper.setPosition(node, position);
				}
			}
		}
		// Create a set of unique node labels from both graphs
		Set<String> nodeLabels = new HashSet<>();
		for (Graph graph : graphs) {
			for (Node node : graph.getNodes()) {
				String label = getLabel(selAttribute, node);
				if (label != null) {
					nodeLabels.add(label);
				}
			}
		}
		// If a node with a unique label attribute is not found in the first graph,
		// calculate its position based on the average position of its neighbors
		for (Graph graph : graphs) {
			for (Node node : graph.getNodes()) {
				String label = getLabel(selAttribute, node);
				if (label != null && !nodePositions.containsKey(label)) {
					Set<Node> nodeNeighbours = node.getNeighbors();
					Double baryCenterX = 0.0;
					Double baryCenterY = 0.0;
					for (Node neighbourNode : nodeNeighbours) {
						baryCenterX += AttributeHelper.getPositionX(neighbourNode);
						baryCenterY += AttributeHelper.getPositionY(neighbourNode);
					}
					Point2D position = new Point2D.Double(baryCenterX / nodeNeighbours.size(),
							baryCenterY / nodeNeighbours.size());
					AttributeHelper.setPosition(node, position);
					nodePositions.put(label, position);
				}
			}
		}
	}

	public static String getLabel(String selAttribute, Node node) {
		if (selAttribute.equals("label")) {
			return AttributeHelper.getLabel(node, null);
		} else {
			return (String) AttributeHelper.getAttribute(node, "identifier").getValue().toString();
		}
	}
}
