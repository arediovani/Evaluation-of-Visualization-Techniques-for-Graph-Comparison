##### VANTED can be started for development with the specified Add-on (see `StartVantedWithAddon.java`).
##### For distribution generate a jar-file under use of the ant-script "createAdd-on.xml"
  * In Eclipse right-click and choose "Run As -> Ant Build".
##### Users can install jar-files by starting VANTED
  * Go to "Edit -> Preferences", open the Add-on Manager and choose "Install Add-on".
  * Alternatively, Drag'n'Drop of the jar-file in VANTED is also supported.
