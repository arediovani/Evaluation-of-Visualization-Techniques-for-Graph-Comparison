import os
import re
import csv

# Folder containing the input files
folder_path = './'

# Prepare CSV output
with open('output.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    # Write the header
    writer.writerow(['File Name', 'User ID', 'Date of Experiment', 'Time Start', 'Time End', 'Question Number', 'Condition', 'Repetition', 'Answer', 'Time Taken'])

    # Iterate over files in the specified folder
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):
            # Read the input data from each file
            with open(os.path.join(folder_path, filename), 'r') as file:
                data = file.read()

            # Extract the user ID, date of the experiment, and start/end times
            user_id = re.search(r'User ID: (.+)', data).group(1)
            date_of_experiment = re.search(r'Date of expermient: (.+)', data).group(1)
            start_time = re.search(r'Date of expermient: .+ (\d+:\d+:\d+)', data).group(1)
            end_time = re.search(r'End Time: (.+)', data).group(1)

            # Find all question blocks
            questions = re.findall(r'Question:(\d+) - Condition:(\w) - Repetition: (\d+).*?Answer: (.*?)\nTime Taken: (.*?)\s', data, re.DOTALL)

            # Write the data rows
            for question in questions:
                question_number, condition, repetition, answer, time_taken = question
                writer.writerow([filename, user_id, date_of_experiment, start_time, end_time, question_number, condition, repetition, answer, time_taken])

print('Data has been written to output.csv')
