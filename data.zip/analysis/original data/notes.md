ne pyetjen e dyte duhet ta bejme qe te matet sa e sakte eshte, jo vertete absolute 
accuracy store 
accuracy = 1 (|r-c|)/ c = 2/8

accuracy  = max (0,1 = |r-c| / c 

average of three repetitions 


for each condition measure time and accurate seperate 
